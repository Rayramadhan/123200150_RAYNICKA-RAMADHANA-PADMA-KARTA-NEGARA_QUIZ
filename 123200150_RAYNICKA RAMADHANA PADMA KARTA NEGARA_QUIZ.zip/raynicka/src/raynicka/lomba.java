/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package Raynicka;
import java.util.Scanner;
public class lomba{
    public static void main(String[] args) {
       Scanner masukan = new Scanner (System.in);
       int pilihan=11;
       do{
           System.out.println ("LOMBA APRESIASI PAHLAWAN WANITA INDONESIA OLEH UPNVYK");
           System.out.println ("TERDAPAT 2 KATEGORI LOMBA:");
           System.out.println ("1. Animasi (tim) ");
           System.out.println ("2. Menulis Surat(individu)");
           System.out.println ("3. exit");
           System.out.println ("Pilih katergori lomba:");
           pilihan=masukan.nextInt();
           switch (pilihan){
               case 1 : animasi();break;
               case 2 : menulissurat();break;
           }
           
       }while(pilihan!=0);
    }

    private static void animasi() {
        Scanner masukan=new Scanner (System.in);
         System.out.println ("++Formulir Pendaftaran++");
         System.out.println ("Masukkan nama (tim):");
         String nama=masukan.next();
         System.out.println ("Masukkan asal sekolah (tim):");
         String asal=masukan.next();
         System.out.println ("++Formulir Penilaian (0-100)++");
         System.out.println ("Input nilai Alur Cerita:");
         int ac=masukan.nextInt();
         System.out.println ("Input nilai Konten:");
         int ko=masukan.nextInt();
         System.out.println ("Input nilai  kreativitas:");
         int kr=masukan.nextInt();
         System.out.println ("Input nilai sinematografi:");
         int si=masukan.nextInt();
         ac= (int) (ac*0.15);
         ko= (int) (ko*0.35);
         kr= (int) (kr*0.35);
         si= (int) (si*0.15);
         
         
         int nilai;
         nilai=(ac+ko+kr+si)/4;
         System.out.println ("nilai akhir" +nama+ ":"+nilai);
         
         if (nilai>= 85){
             System.out.println ("selamat" +nama+ "dengan asal  sekolah" +asal+ "dinyatakan lolos seleksi");
             
         }else
             System.out.println ("Mohon maaf" +nama+ "dengan asal  sekolah" +asal+ "tidak lolos seleksi");
         
         
         
         
         
   
         
    }

    private static void menulissurat() {
        Scanner masukan=new Scanner (System.in);
         System.out.println ("++Formulir Pendaftaran++");
         System.out.println ("Masukkan nama :");
         String nama=masukan.next();
         System.out.println ("Masukkan asal sekolah :");
         String asal=masukan.next();
         System.out.println ("++Formulir Penilaian (0-100)++");
         System.out.println ("Input nilai struktur surat:");
         int su=masukan.nextInt();
         System.out.println ("Input nilai isi surat:");
         int is=masukan.nextInt();
         System.out.println ("Input nilai  kreativitas:");
         int kr=masukan.nextInt();
         System.out.println ("Input nilai penerapan kaidah bahasa:");
         int pk=masukan.nextInt();
         su= (int) (su*0.10);
         is= (int) (is*0.40);
         kr= (int) (kr*0.30);
         pk= (int) (pk*0.20);
         
         int nilai;
         nilai=(su+is+kr+pk)/4;
         System.out.println ("nilai akhir" +nama+ ":"+nilai);
         
         if (nilai>= 85){
             System.out.println ("selamat" +nama+ "dengan asal sekolah" +asal+ "dinyatakan lolos seleksi");
             
         }else
             System.out.println ("Mohon maaf" +nama+ "dengan asal  sekolah" +asal+ "tidak lolos seleksi");
         
    }
               
           }
                   
